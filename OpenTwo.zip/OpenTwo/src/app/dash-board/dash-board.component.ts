import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dash-board',
  templateUrl: './dash-board.component.html',
  styleUrls: ['./dash-board.component.css']
})
export class DashBoardComponent implements OnInit {

  // title:string="Hello World!";

  miniParagragh: string = "dapp-dash-boardapp-dash-boardapp-dash-board";
  code: string = "Angular";
  valueOne: string = "Property Binding";
  show2db: string = "";

users = [{name: 'Gopi', age:26, gender:'m'},
{name: 'Bharath', age:29, gender:'m'},
{name: 'Praveen', age:24, gender:'m'},
{name: 'Amritha', age:26, gender:'f'},
{name: 'Pooja', age:25, gender:'f'},
{name: 'Shankar', age:30, gender:'m'}];s

  constructor() { }

  ngOnInit(): void {
  }

  openOne() {
    alert("Learn to Code  ")
  }
}
