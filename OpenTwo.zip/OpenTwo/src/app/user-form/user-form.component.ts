import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup,FormArray,Validators } from '@angular/forms';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent implements OnInit {
  
  userForm:FormGroup;

  constructor() { 
this.userForm = new FormGroup({
'firstName' : new FormControl("",Validators.required),
'lastName' : new FormControl("",Validators.required),
'email' : new FormControl("", [Validators.required,Validators.email])

})
  }

  ngOnInit(): void {
  }
 
  inputLastName:string="Hello";

  // newValue="This is new Value";
  // newHTML="<h2>This is new Inner HTML</h2>";
    
  submit(){
  alert("Submitted")
}

userFsub(){
  console.log(this.userForm.value);
}

}
